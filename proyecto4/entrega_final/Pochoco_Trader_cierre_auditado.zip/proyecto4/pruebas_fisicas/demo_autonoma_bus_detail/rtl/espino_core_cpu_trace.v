// Copyright 2026 Universidad de los Andes.
// Licensed under the Solderpad Hardware License, Version 0.51 (the "License");
// you may not use this file except in compliance with the License.
// SPDX-License-Identifier: SHL-0.51
//
// Course: Arquitectura de Computadores (2026)
// 
// Authors:
// - Nicolás Villegas <navillegas@miuandes.cl>

// Diagnostic clone of the original Espino core with observation outputs.
// The immutable demo ROM can use its verified, word-aligned address range.
module espino_core_cpu_trace #(
  parameter [31:0] BootAddr = 32'h0000_0000,
  parameter integer FETCH_WORD_BITS = 0
) (
  input  wire        clk_i,
  input  wire        rst_ni,

  output wire        instr_req_o,
  output wire [31:0] instr_addr_o,
  input  wire [31:0] instr_rdata_i,

  output wire        data_req_o,
  output wire        data_we_o,
  output wire [3:0]  data_be_o,
  output wire [31:0] data_addr_o,
  output wire [31:0] data_wdata_o,
  input  wire [31:0] data_rdata_i,
  output wire        dbg_commit_o,
  output wire        dbg_stall_o,
  output wire        dbg_instr_valid_o,
  output wire        dbg_lsu_busy_o,
  output wire [31:0] dbg_instr_id_o,
  output wire [31:0] dbg_pc_id_o,
  output wire [31:0] dbg_operand_a_o, dbg_operand_b_o,
  output wire dbg_branch_taken_o, dbg_pc_set_o
);

  wire [31:0] pc_id;
  wire        instr_valid_id;

  wire        pc_set;
  wire        stall;
  wire [31:0] pc_target;
  wire        branch_taken;
  wire        jump;

  wire [3:0]  rf_raddr_a, rf_raddr_b, rf_waddr;
  wire [31:0] rf_rdata_a, rf_rdata_b, rf_wdata;
  wire        rf_we;
  wire        rf_ready;

  wire        lsu_req, lsu_we, lsu_sign, lsu_busy;
  wire [1:0]  lsu_type;
  wire [31:0] lsu_addr, lsu_wdata, lsu_rdata;

  wire        illegal_insn;

  assign dbg_commit_o = instr_valid_id & ~stall;
  assign dbg_stall_o  = stall;
  assign dbg_instr_valid_o = instr_valid_id;
  assign dbg_lsu_busy_o = lsu_busy;
  assign dbg_instr_id_o = instr_rdata_i;
  assign dbg_pc_id_o  = pc_id;
  assign dbg_operand_a_o = rf_rdata_a;
  assign dbg_operand_b_o = rf_rdata_b;
  assign dbg_branch_taken_o = branch_taken;
  assign dbg_pc_set_o = pc_set;

  generate if (FETCH_WORD_BITS==0) begin : g_full_fetch
    espino_if_stage #(.BootAddr(BootAddr)) u_if (
      .clk_i(clk_i), .rst_ni(rst_ni), .pc_set_i(pc_set), .pc_target_i(pc_target),
      .stall_i(stall), .instr_req_o(instr_req_o), .instr_addr_o(instr_addr_o),
      .pc_id_o(pc_id), .instr_valid_id_o(instr_valid_id)
    );
  end else begin : g_rom_fetch
    reg [FETCH_WORD_BITS-1:0] fetch_word, id_word;
    reg id_valid;
    always @(posedge clk_i or negedge rst_ni) begin
      if(!rst_ni) begin
        fetch_word<=BootAddr[FETCH_WORD_BITS+1:2];
        id_word<=BootAddr[FETCH_WORD_BITS+1:2];
        id_valid<=0;
      end else if(!stall) begin
        fetch_word<=pc_set ? pc_target[FETCH_WORD_BITS+1:2] : fetch_word+1'b1;
        id_word<=fetch_word;
        id_valid<=!pc_set;
      end
    end
    assign instr_req_o=!stall;
    assign instr_addr_o={{(30-FETCH_WORD_BITS){1'b0}},fetch_word,2'b00};
    assign pc_id={{(30-FETCH_WORD_BITS){1'b0}},id_word,2'b00};
    assign instr_valid_id=id_valid;
  end endgenerate

  espino_id_stage u_id (
    .clk_i          (clk_i),
    .rst_ni         (rst_ni),
    .instr_valid_i  (instr_valid_id),
    .instr_rdata_i  (instr_rdata_i),
    .pc_id_i        (pc_id),
    .stall_i        (stall),
    .rf_raddr_a_o   (rf_raddr_a),
    .rf_raddr_b_o   (rf_raddr_b),
    .rf_rdata_a_i   (rf_rdata_a),
    .rf_rdata_b_i   (rf_rdata_b),
    .rf_waddr_o     (rf_waddr),
    .rf_wdata_o     (rf_wdata),
    .rf_we_o        (rf_we),
    .lsu_req_o      (lsu_req),
    .lsu_we_o       (lsu_we),
    .lsu_type_o     (lsu_type),
    .lsu_sign_o     (lsu_sign),
    .lsu_addr_o     (lsu_addr),
    .lsu_wdata_o    (lsu_wdata),
    .lsu_rdata_i    (lsu_rdata),
    .branch_taken_o (branch_taken),
    .jump_o         (jump),
    .pc_target_o    (pc_target),
    .rf_ready_o     (rf_ready),
    .illegal_insn_o (illegal_insn)
  );

  espino_register_file u_rf (
    .clk_i     (clk_i),
    .rst_ni    (rst_ni),
    .raddr_a_i (rf_raddr_a),
    .rdata_a_o (rf_rdata_a),
    .raddr_b_i (rf_raddr_b),
    .rdata_b_o (rf_rdata_b),
    .waddr_i   (rf_waddr),
    .wdata_i   (rf_wdata),
    .we_i      (rf_we)
  );

  espino_load_store_unit u_lsu (
    .clk_i        (clk_i),
    .rst_ni       (rst_ni),
    .req_i        (lsu_req),
    .we_i         (lsu_we),
    .type_i       (lsu_type),
    .sign_i       (lsu_sign),
    .addr_i       (lsu_addr),
    .wdata_i      (lsu_wdata),
    .rdata_o      (lsu_rdata),
    .busy_o       (lsu_busy),
    .data_req_o   (data_req_o),
    .data_we_o    (data_we_o),
    .data_be_o    (data_be_o),
    .data_addr_o  (data_addr_o),
    .data_wdata_o (data_wdata_o),
    .data_rdata_i (data_rdata_i)
  );

  espino_controller u_ctrl (
    .instr_valid_i  (instr_valid_id),
    .rf_ready_i     (rf_ready),
    .branch_taken_i (branch_taken),
    .jump_i         (jump),
    .lsu_busy_i     (lsu_busy),
    .pc_set_o       (pc_set),
    .stall_o        (stall)
  );

endmodule
