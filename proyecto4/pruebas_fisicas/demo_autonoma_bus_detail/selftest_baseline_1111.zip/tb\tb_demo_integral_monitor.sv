`timescale 1ns/1ps
module tb_demo_integral_monitor;
  reg clk=0;
  always #5 clk=~clk;
  reg rst=1, byte_done=0, response_valid=0;
  reg [3:0] access=0;
  reg timeout=0;
  reg [7:0] response=0;
  wire [3:0] led;
  wire error;
  demo_integral_monitor dut(clk,rst,byte_done,byte_done,byte_done,access,4'd0,timeout,1'b0,response==0,
    8'd200,8'd0,response_valid,1'b0,led,error);
  task step;
    begin @(posedge clk); #1; end
  endtask
  task reset;
    begin rst=1; access=0; response=0; response_valid=0; byte_done=0;
      step; rst=0; end
  endtask
  task price;
    begin byte_done=1; step; byte_done=0; end
  endtask
  initial begin
    reset;
    price;
    // Simultaneous sticky accesses and a held PRICE request.
    access=5'b00111; repeat(4) step;
    if(error || dut.n_read!=1 || dut.n_sum!=1 || dut.n_ready!=1)
      $fatal(1,"simultaneous or held accesses counted incorrectly");
    access=8; response_valid=1; step;
    access=0; response_valid=0; step;
    if(error || dut.n_write!=1 || dut.n_response!=1)
      $fatal(1,"simultaneous DECISION/MISO lost");
    access=8; step;
    if(!error || led!=15) $fatal(1,"duplicate DECISION missed");
    access=0; step;
    if(!error) $fatal(1,"error did not latch");
    reset; price; price;
    if(!error) $fatal(1,"overwritten price missed");
    reset; price; response=8'hff; response_valid=1; step;
    if(!error) $fatal(1,"wrong MISO missed");
    reset; price;
    timeout=1; step;
    if(!error) $fatal(1,"timeout missed");
    $display("PASS integral monitor: simultaneous, held request, duplicate, overwrite, MISO and timeout");
    $finish;
  end
endmodule


