module demo_integral_monitor(
  input wire clk,rst,byte_done,first_commit,status_valid,
  input wire [3:0] access,frame_index,
  input wire transport_timeout,frame_start,response_ok,
  input wire [7:0] price,decision,
  input wire response_valid,master_done,
  output reg [3:0] led=0,
  output reg error=0
);
  reg [7:0] prices[0:15], decisions[0:15];
  initial begin
    $readmemh("proyecto4/pruebas_fisicas/demo_autonoma_bus_detail/data/prices.hex",prices);
    $readmemh("proyecto4/pruebas_fisicas/demo_autonoma_bus_detail/data/expected_writes.hex",decisions);
  end
  reg [3:0] previous_access=0;
  wire [3:0] events=access & ~previous_access;
  wire price_read=events[0],sum_read=events[1],ready_read=events[2],write_decision=events[3];
  // One shared tick index plus sticky per-tick events encodes the six
  // saturating counts. Each new tick requires every previous event.
  reg in_tick=0;
  wire [4:0] n_price={1'b0,frame_index}+in_tick;
  reg [4:0] tick_seen=0;
  wire [4:0] tick_events={response_valid,events[3:0]};
  wire [4:0] prior_ticks={1'b0,frame_index};
  wire [4:0] n_read=prior_ticks+tick_seen[0], n_sum=prior_ticks+tick_seen[1],
             n_ready=prior_ticks+tick_seen[2], n_write=prior_ticks+tick_seen[3],
             n_response=prior_ticks+tick_seen[4];


  reg [9:0] hits=0;
  wire [9:0] reached;
  assign reached[0]=hits[0];
  genvar i;
  generate for(i=1;i<10;i=i+1) begin : milestones
    assign reached[i]=reached[i-1] && hits[i];
  end endgenerate
  wire [3:0] stage={
    reached[7],
    reached[3] && !reached[7],
    (reached[1] && !reached[3]) || (reached[5] && !reached[7]) || reached[9],
    (reached[0] && !reached[1]) || (reached[2] && !reached[3]) ||
    (reached[4] && !reached[5]) || (reached[6] && !reached[7]) ||
    (reached[8] && !reached[9])
  };
  wire drained=&tick_seen;
  wire complete=master_done && in_tick && drained;
  wire fault=(stage!=10 && transport_timeout) ||
    (frame_start && frame_index!=0 && (!in_tick || !drained)) ||
    (byte_done && (in_tick || price!=prices[frame_index])) ||
    (|tick_events && (!in_tick || frame_start || |(tick_seen & tick_events))) ||
    ((sum_read || ready_read) && !(tick_seen[0] || price_read)) ||
    (write_decision && (!(tick_seen[1] || sum_read) ||
       !(tick_seen[2] || ready_read) || decision!=decisions[frame_index])) ||
    (response_valid && !response_ok);
  always @(posedge clk) begin
    if (rst) begin
      previous_access<=0;
      in_tick<=0; tick_seen<=0;
      hits<=0; error<=0; led<=0;
    end else begin
      previous_access<=access;
      if(frame_start) in_tick<=0;
      if(byte_done) in_tick<=1;
      tick_seen<=frame_start ? 5'd0 : tick_seen | tick_events;
      hits<=hits | {complete && !error && !fault, complete, response_valid,
                   write_decision,ready_read,sum_read,price_read,status_valid,first_commit,byte_done};
      error<=error || fault;

      led<=error || fault ? 4'hf : stage;
    end
  end
endmodule






