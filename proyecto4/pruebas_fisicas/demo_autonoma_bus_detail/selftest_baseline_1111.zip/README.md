﻿# Demostración integral SPI del Pochoco SoC

La captura física previa 0101 queda preservada en pc_probe_aprobado.zip, que contiene sus fuentes, scripts, vectores, PCF y BIN. SHA-256 del BIN aprobado: CF9C849A1D7FAFD710D66B021CC5C9053A7CB7B9806D86BA69061D46201AF25C. SHA-256 del ZIP: 082922E4F5F8E98794CCE35E0344EA8C099AF07DAD1FDE67946C64E6CC9722E2.

El monitor nuevo usa señales de observación. Mantiene un índice saturado de precios y cinco flags del tick actual. El conteo de cada acceso equivale a los ticks cerrados más su flag del tick actual. Un precio siguiente exige que el anterior tenga PRICE, SUM10, READY, DECISION y MISO. Las solicitudes de un mismo tipo mantenidas en ciclos consecutivos se cuentan una vez. Los vectores de referencia en data/ alimentan las comparaciones de precio, DECISION y MISO. La primera respuesta MISO corresponde al valor inicial. Las siguientes corresponden a la decisión anterior.

El maestro reutiliza su contador de intervalo para detectar aproximadamente 328 us de espera sin ACK o sin completar el último tick. El error queda enclavado. Los hitos normales son acumulativos. Si llegan juntos, todos se retienen y el código puede saltar al último hito consecutivo observado. Un código significa que se observaron todos los hitos anteriores. Los códigos intermedios pueden durar muy poco para percibirlos a simple vista.

| D4..D1 | Hito |
|---|---|
| 0000 | Reset o espera del primer precio |
| 0001 | Primer precio SPI recibido |
| 0010 | Primer commit posterior al precio en PC 0x14 |
| 0011 | Respuesta STATUS con new_price=1 |
| 0100 | Lectura PRICE |
| 0101 | Lectura SUM10 |
| 0110 | Lectura READY |
| 0111 | Escritura DECISION |
| 1000 | Respuesta MISO recibida |
| 1001 | 16 ticks completos |
| 1010 | PASS integral de los vectores y la secuencia |
| 1111 | Error enclavado |
| 1011 a 1110 | Reservados |

## Reproducción desde pochoco_soc-main

```powershell
powershell -ExecutionPolicy Bypass -File proyecto4/pruebas_fisicas/demo_autonoma_bus_detail/ejecutar_pruebas.ps1
powershell -ExecutionPolicy Bypass -File proyecto4/pruebas_fisicas/demo_autonoma_bus_detail/sintetizar.ps1
```

- Icarus unitario aprobado. El monitor prueba simultaneidad, solicitud mantenida, DECISION duplicada, precio sobrescrito, MISO incorrecto y timeout.
- Icarus integrado aprobado con LED 1010, 16 precios, 16 lecturas de cada registro PRICE, SUM10 y READY, 16 DECISION, 16 MISO y 15 ACK en orden. El log build/simulacion_integrada.log incluye la comparación exacta con los vectores Python y la traza del primer commit.

- Yosys completó con 1.082 LUT4 y 9 BRAM. El PCF asigna cinco pines únicos y el chequeo de netlist aprobó.
- nextpnr HX1K/VQ100 colocó y enrutó 1.273/1.280 LC. Fmax final 39,90 MHz y PASS a 25 MHz. Quedan 7 LC libres. El objetivo preferido de 1.220 LC quedó a 53 LC.
- icepack generó build/demo_autonoma_bus_detail.bin. SHA-256 B1E855DE663F99A2C796495CB09C8CF08E538B231FA82CC777D846E286EBE430.
- La comprobación física integral sigue pendiente.

## Auditoría de área

| Implementación medida | LUT4 | LC | LC recuperadas |
|---|---:|---:|---:|
| Monitor integral original | 1117 | 1331 | — |
| Índice y temporizador del maestro reutilizados y segundo registro MISO eliminado | 1104 | 1305 | 26 |
| Comparación MISO bit a bit y contabilidad por trama | 1094 | 1293 | 12 |
| Índice de 4 bits y código LED derivado de los flags | 1082 | 1273 | 20 |

Los logs completos se conservan en build/. La ocupación del PC Probe con evidencia física fue 1140 LC, frente a 1331 del monitor inicial. Además de la lógica de diagnóstico, la comparación integral mantiene vivo el camino de recepción MISO que el PC Probe podía podar.

La netlist inicial asignó 95 LUT4 y 63 FF con prefijo u_monitor, incluyendo el watchdog, los flags de transacción y el estado del indicador. nextpnr reportó 930 celdas LUT4 sin FF, 187 con LUT4 y FF y 181 solo con FF. El mayor grupo de nombres en la netlist es u_soc.u_ram, 726 LUT4 y cuatro BRAM. La síntesis plana comparte y renombra lógica que usa datos de RAM, por lo que ese prefijo no equivale al costo aislado de la RAM. Las nueve BRAM se atribuyen a RAM principal (4), banco de registros (4) e historial SMA10 (1). La diferencia de LC entre ejecuciones es la medida de ahorro, no la suma de prefijos.

Los bytes previstos son 00, 50 y 90, así que se pueden representar con dos bits en la referencia. La lectura de la ROM constante ya permite a síntesis eliminar los cinco bits siempre cero. La comparación conserva los ocho bits transmitidos, incluidos los que deben ser cero. El maestro acumula un único flag de discrepancia al muestrear cada bit de MISO. Icarus conserva también el byte ensamblado y lo coteja con el vector original. No se modificó el formato DECISION ni los vectores Python.

## Programación manual desde pochoco_soc-main

```powershell
$bin = 'proyecto4/pruebas_fisicas/demo_autonoma_bus_detail/build/demo_autonoma_bus_detail.bin'
Get-FileHash -Algorithm SHA256 $bin
iceprog $bin
```

Comprueba el SHA-256 anterior, espera VERIFY OK y reinicia la placa. PASS integral esperado en D4..D1 es 1010 (D4 y D2 encendidos). 1111 indica error enclavado.
